//
//  PriceTagApp.swift
//  PriceTag
//
//  Created by atique aqtab on 2026-09-13.
//

import SwiftUI

@main
struct PriceTagApp: App {
    @StateObject private var store = Store()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
        }
    }
}

import SwiftUI
import Combine

@MainActor
final class Store: ObservableObject {

    @Published var pages: [SignPage] = [] {
        didSet { save() }
    }

    @Published var library: [Sign] = [] {
        didSet { save() }
    }

    private struct Payload: Codable {
        var pages: [SignPage]
        var library: [Sign]
    }

    private var fileURL: URL {
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return dir.appendingPathComponent("pricetag.json")
    }

    init() {
        guard let data = try? Data(contentsOf: fileURL) else { return }
        guard let payload = try? JSONDecoder().decode(Payload.self, from: data) else { return }
        pages = payload.pages
        library = payload.library
    }

    private func save() {
        let payload = Payload(pages: pages, library: library)
        guard let data = try? JSONEncoder().encode(payload) else { return }
        try? data.write(to: fileURL, options: .atomic)
    }

    /// A printed page always shows four signs. Short pages repeat what is there.
    func printable(_ page: SignPage) -> [Sign] {
        let signs = page.signs
        if signs.isEmpty { return [] }
        var out: [Sign] = []
        for i in 0..<4 {
            out.append(signs[i % signs.count])
        }
        return out
    }
}

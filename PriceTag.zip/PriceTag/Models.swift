//
//  Models.swift
//  PriceTag
//
//  Created by atique aqtab on 2026-09-13.
//

import Foundation

enum SignType: String, Codable, CaseIterable, Identifiable {
    case regular
    case sale
    case clearance
    case used
    case apparel
    case parts

    var id: String { return rawValue }

    var title: String {
        switch self {
        case .regular:   return "Regular item"
        case .sale:      return "Sale - was / now"
        case .clearance: return "Clearance"
        case .used:      return "Used / pre-owned"
        case .apparel:   return "Boots & apparel"
        case .parts:     return "Part with fitment"
        }
    }

    var banner: String? {
        switch self {
        case .sale:      return "SALE"
        case .clearance: return "CLEARANCE"
        case .used:      return "PRE-OWNED"
        default:         return nil
        }
    }
}

struct Sign: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var type: SignType = .regular
    var brand: String = "Shoei"
    /// Which version of the brand mark to print, when that brand has more than one.
    var brandVariant: String?
    var name: String = ""
    var variant: String = ""
    var size: String = ""
    var price: String = ""
    var cents: String = ""
    var regularPrice: String = ""
    var percentOff: String = ""
    var partNumber: String = ""
    var fitment: [String] = []
    var condition: String = ""
    var note: String = ""
    var featureLogos: [String] = []
    var splitCents: Bool = true
}

struct SignPage: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var title: String = "Untitled page"
    var signs: [Sign] = []
}

extension URL: Identifiable {
    public var id: String { return absoluteString }
}

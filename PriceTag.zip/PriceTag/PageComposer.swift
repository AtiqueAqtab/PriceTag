//
//  PageComposer.swift
//  PriceTag
//
//  Created by atique aqtab on 2026-09-14.
//

import SwiftUI

struct PageComposer: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) private var dismiss
    @Binding var page: SignPage

    @State private var pickingType = false
    @State private var editing: Int? = nil
    @State private var pdfURL: URL? = nil
    @State private var showShare = false

    var body: some View {
        ZStack(alignment: .bottom) {
            Color.ptBG.ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    HStack {
                        Button(action: { dismiss() }) {
                            Text("← Pages")
                                .font(pt(15, .medium))
                                .foregroundColor(.ptAccent)
                        }
                        Spacer()
                        NavigationLink(destination: PrintPreview(page: page)) {
                            Text("Preview")
                                .font(pt(15, .medium))
                                .foregroundColor(.ptAccent)
                        }
                    }
                    .padding(.top, 4)

                    TextField("", text: $page.title, prompt:
                        Text("Untitled page").foregroundColor(Color.white.opacity(0.3))
                    )
                    .font(pt(28, .bold))
                    .foregroundColor(.white)
                    .padding(.top, 14)

                    Text("\(page.signs.count) of 4 filled · letter, 0.5in margins")
                        .font(pt(13))
                        .foregroundColor(.ptDim)
                        .padding(.top, 6)

                    VStack(spacing: 7) {
                        ForEach(Array(page.signs.enumerated()), id: \.element.id) { index, sign in
                            Button(action: { editing = index }) {
                                ScaledSign(sign: sign)
                            }
                            .buttonStyle(.plain)
                        }

                        if page.signs.count < 4 {
                            Button(action: { pickingType = true }) {
                                Text("+ Add sign")
                                    .font(pt(13, .medium))
                                    .foregroundColor(Color.black.opacity(0.35))
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 72)
                                    .overlay(
                                        Rectangle().strokeBorder(
                                            Color.black.opacity(0.2),
                                            style: StrokeStyle(lineWidth: 2, dash: [6, 4])
                                        )
                                    )
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(7)
                    .background(Color.white)
                    .cornerRadius(8)
                    .padding(.top, 22)

                    Text("Tap a sign to edit · border is the cut line")
                        .font(pt(11))
                        .foregroundColor(Color.white.opacity(0.3))
                        .frame(maxWidth: .infinity)
                        .padding(.top, 8)
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 120)
            }

            HStack(spacing: 10) {
                PillButton(title: "Add sign") { pickingType = true }
                PillButton(title: "Export PDF", filled: true) {
                    pdfURL = exportPDF(page: page, signs: store.printable(page))
                    showShare = pdfURL != nil
                }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 12)
            .background(
                LinearGradient(
                    colors: [Color.ptBG.opacity(0), Color.ptBG],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()
            )
        }
        .navigationBarHidden(true)
        .sheet(isPresented: $pickingType) {
            TypePicker { type in
                page.signs.append(Sign(type: type))
                pickingType = false
                editing = page.signs.count - 1
            }
        }
        .sheet(item: Binding(
            get: { editing.map { EditTarget(index: $0) } },
            set: { editing = $0?.index }
        )) { target in
            NavigationStack {
                SignEditor(sign: $page.signs[target.index]) {
                    store.library.append(page.signs[target.index])
                }
            }
        }
        .sheet(isPresented: $showShare) {
            if let url = pdfURL { ActivityView(url: url) }
        }
    }
}

struct EditTarget: Identifiable {
    let index: Int
    var id: Int { return index }
}
